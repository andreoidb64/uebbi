#!/bin/sh
################################################################################
# file: /flash/update.sh
# auth: andreoidb64
# date: 20160214
#       20161124 andreoidb64: 
#
#
################################################################################
# ... Set vars
LOGFILE=/dev/console
LOGFILE=$0.log
> $LOGFILE # Clean log file

################################################################################
# ... Define functions
ShowMsg()
{
	echo  "$1" "$2" >> $LOGFILE 2>&1
	putfb "$1" "$2"
	sleep $3
}

TheEnd()
{
	case $1 in
	0)	ShowMsg "ALL Write OK, Reboot" " " 1
		;;
	1)	ShowMsg " " "This is not Alchemy" 1
		;;
 	2)	ShowMsg "Error!! putimage!" "Try again" 1
 		;;
	3)	ShowMsg "There is no md5checksum." "ABORT!" 1
		;;
	4)	ShowMsg "Fail to check md5." "ABORT!" 1
		;;
	5)	ShowMsg "Error!!" "Unmounting /usr/prizm_mid!" 1
		;;
	*)	;;
	esac
	sleep 1
	reboot -f
}

FlashRewrite()
{
  case $1 in
	yboot.bin-milano)
		PART="/dev/mtd0"
		MSG01="Run nandwrite boot..."
		NWOPT="-p"
		UMOUNT="nothing"
		;;
	zImage-milano)
		PART="/dev/mtd1"
		MSG01="Run nandwrite kernel..."
		NWOPT="-p"
		UMOUNT="nothing"
		;;
	root.cramfs-milano)
		PART="/dev/mtd2"
		MSG01="Run nandwrite root..."
		NWOPT="-p"
		UMOUNT="nothing"
		;;
	app.cramfs-milano)
		PART="/dev/mtd3"
		MSG01="Run nandwrite app..."
		NWOPT="-p"
		UMOUNT="/usr/prizm_mid"
		;;
	factory.yaffs2-milano)
		PART="/dev/mtd4"
		MSG01="Run nandwrite factory..."
		NWOPT="-a -o"
		UMOUNT="/factory"
		;;
	data.yaffs2-milano)
		PART="/dev/mtd5"
		MSG01="Run nandwrite data..."
		NWOPT="-a -o"
		UMOUNT="/root"
		;;
	*)
		return 1
		;;
  esac

  [ "$UMOUNT" != "nothing" ] && umount $UMOUNT
  ShowMsg "$MSG01" " " 2
  #putfb "DO NOT remove SD Card or Power Off" ""
	if [ -f md5sum.dryrun ]
	then
 		ShowMsg "Flash Erase         " "$PART  " 2
		ShowMsg "NAND Write          " "$1 to $PART" 2
	else
 		ShowMsg "Flash Erase         " "$PART  " 1
		flash_eraseall $PART >> $LOGFILE 2>&1
		ShowMsg "NAND Write          " "$1 to $PART" 1
 		nandwrite $NWOPT $PART $1 >> $LOGFILE 2>&1
	fi
  if [ "$?" = "0" ]
  then
 	ShowMsg "$1  " "Write OK" 2
  else
	TheEnd 2
  fi
}

################################################################################
# ... Run preliminary checks

#putfb "123456789.123456789.123456789.123" "123456789.123456789.123456789.123"

grep -q -i "system type.*Alchemy" /proc/cpuinfo
#true
[ "$?" != "0" ] && TheEnd 1

if [ -f md5sum.disable ]
then
	# Only for developers.
	ShowMsg "Checksum disabled!!!" "DO NOT USE for distribution!" 2
else
	[ ! -f md5sum.txt ] && TheEnd 3
	
	ShowMsg "Check md5sum files" "...   " 1
	md5sum -c md5sum.txt >> $LOGFILE 2>&1
	[ $? != "0" ] && TheEnd 4
fi

################################################################################
# ... Umount /usr/prizm_mid

UUSR=`cat /proc/mounts | grep prizm_mid | cut -f2 -d ' '`
if [ "$UUSR" ]
then
	echo "Unmounting /usr..." >> $LOGFILE 2>&1
	for i in `fuser -m /usr/prizm_mid`; do
		kill -9 ${i}
	done

	sleep 2

	umount /usr/prizm_mid
	if [ "$?" != 0 ]; then
		TheEnd 5
	fi
else
	echo "Already unmounted /usr/prizm_mid" >> $LOGFILE 2>&1
fi

################################################################################
# ... Get list of images to refresh against md5sum.txt list

BOOT_IMG="yboot.bin-milano"
KERNEL_IMG="zImage-milano"
ROOT_IMG="root.cramfs-milano"
APP_IMG="app.cramfs-milano"
FACTORY_IMG="factory.yaffs2-milano"
DATA_IMG="data.yaffs2-milano"

IMGS=""
while read MD5 FILE
do
	[ ! -f "$FILE" ] && continue
	for DUMMY in $BOOT_IMG $KERNEL_IMG $ROOT_IMG $APP_IMG $FACTORY_IMG $DATA_IMG
	do
		[ "$DUMMY" != "$FILE" ] && continue
		IMGS=$IMGS' '$FILE
	done
done < md5sum.txt

# ... So far nothing changed on your device.
################################################################################
# ... Lets start to write images now!

for i in $IMGS; do
	FlashRewrite ${i}
done

TheEnd 0
